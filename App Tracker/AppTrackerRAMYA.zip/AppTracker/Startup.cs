﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(AppTracker.Startup))]
namespace AppTracker
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
