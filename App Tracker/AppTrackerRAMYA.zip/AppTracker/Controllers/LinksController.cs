﻿


using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.EnterpriseServices;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.DynamicData;
using System.Web.Mvc;
using AppTracker.Models;
using AppTracker.ViewModels;
using AppTracker.Services;
using AppTracker.Services.Models;
using AppTracker.Services.Services;


namespace AppTracker.Controllers
{
    public class LinksController : Controller
    {
        private db_UAB_AppTrackerEntities db = new db_UAB_AppTrackerEntities();

        LinksService _linkservice = new LinksService();

        public PartialViewResult GetApps(Guid? DepartmentGuid)
        {




            var query = (from l in db.Links
                join d in db.Departments on l.DepartmentGuid equals d.DepartmentGuid
                join t in db.Types on l.TypeId equals t.TypeId
                where l.TypeId == 1
                where l.DepartmentGuid == DepartmentGuid
                select l);


            return PartialView("~/Views/Shared/_ViewLinkPartial.cshtml",
                query.Select(x => new LinkVM
                {

                    //changed typeid to in HEADS UP
                    DepartmentGuid = x.DepartmentGuid,
                    TypeId = x.TypeId,
                    Description = x.Description,
                    Production = x.Production,
                    Development = x.Development,
                    Created = x.Created,

                    Modified = x.Modified,
                    ProjectName = x.ProjectName,
                    DepartmentName = x.Department.Name,
                    typeName = x.Type.TypeName

                }).ToList());
        }





        public PartialViewResult GetReports(Guid? DeptartmentGuid)
        {


     




            var query = (from l in db.Links
                join d in db.Departments on l.DepartmentGuid equals d.DepartmentGuid
                join t in db.Types on l.TypeId equals t.TypeId
                where l.TypeId == 2
                where l.DepartmentGuid == DeptartmentGuid
                select l);



            return PartialView("~/Views/Shared/_ViewLinkPartial.cshtml",
                query.Select(x => new LinkVM
                {
                    //changed typeid to in HEADS UP
                    DepartmentGuid = x.DepartmentGuid,
                    TypeId = x.TypeId,
                    Description = x.Description,
                    Production = x.Production,
                    Development = x.Development,
                    Created = x.Created,
                    Modified = x.Modified.Value,
                    ProjectName = x.ProjectName,
                    DepartmentName = x.Department.Name,
                    typeName = x.Type.TypeName
                }).ToList());

        }



        


        // GET: Links
        public ActionResult Index()
        {
            return View();
        }

        // GET: Links/Details/5
        public ActionResult Details(int id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Link link = db.Links.Find(id);
            if (link == null)
            {
                return HttpNotFound();
            }
            return View(link);
        }

        // GET: Links/Create

   
        public ActionResult Create()
        {
            var  newlink = new LinkVM();
            {
                
                newlink.Departments = new SelectList(db.Types, "DepartmentGuid", "Name");
                newlink.Types = new SelectList(db.Types, "TypeId", "TypeName");
                newlink.Created = DateTime.Now;
                newlink.Modified = null;
                
            }
            
            return View(newlink);

             }
     
        // POST: Links/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(LinkVM link)
        {
            
                if (ModelState.IsValid)
                {
                    link.Departments = new SelectList(db.Departments, "DepartmentGuid", "Name");
                    link.Types = new SelectList(db.Types, "TypeId", "TypeName");
                    db.Links.Add(link);
                    db.SaveChanges();
                   return RedirectToAction("Index");
                }

            return View();
        }

        // GET: Links/Edit/5
        public ActionResult Edit(int id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }


            var targetedLink = _linkservice.GetLinkByID(id);


            EditLinkViewModel link = new EditLinkViewModel(targetedLink);
            {

                link.Departments = new SelectList(db.Departments, "DepartmentGuid", "Name");
                link.Types = new SelectList(db.Types, "TypeId", "TypeName");

            }
       
           
            if (link == null)
            {
                return HttpNotFound();
            }
            
            return View(link);
        }

        // POST: Links/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(EditLinkViewModel link)
        {
            if (ModelState.IsValid)
            {

                link.Departments = new SelectList(db.Departments, "DepartmentGuid", "Name");
                link.Types = new SelectList(db.Types, "TypeId", "TypeName");
                db.Entry(link).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");

            }
            
            return View(link);
        }

        // GET: Links/Delete/5
        public ActionResult Delete(int id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Link link = db.Links.Find(id);
            if (link == null)
            {
                return HttpNotFound();
            }
            return View(link);
        }

        // POST: Links/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
           
            Link link = db.Links.Find(id);
            db.Links.Remove(link);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
