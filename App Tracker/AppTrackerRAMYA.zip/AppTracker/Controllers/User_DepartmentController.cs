﻿using AppTracker.Models;
using AppTracker.ViewModels;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace AppTracker.Controllers
{
    public class User_DepartmentController : Controller
    {
        private db_UAB_AppTrackerEntities db = new db_UAB_AppTrackerEntities();




        public PartialViewResult DeptMenu(string DepartmentID)
        {


            var query = (from u in db.Users
                         join ud in db.UserDepartments on u.Id equals ud.UserId
                         join d in db.Departments on ud.DepartmentGuid equals d.DepartmentGuid
                         where u.Id == 12
                         select d);


            return PartialView("~/Views/Shared/_DepartmentPartial.cshtml", query.Select(x => new UserDeptVM { DepartmentGuid = x.DepartmentGuid, DepartmentName = x.Name }).ToList());

            //var result = (from s in db.Departments join r in db.User_Department on s.ID equals r.DepartmentID where r.UserID == 1 select r);
            //return PartialView(result);
        }

        // GET: User_Department
        public ActionResult Index()
        {
            var user_Department = db.UserDepartments.Include(u => u.Department).Include(u => u.User);
            return View(user_Department.ToList());
        }

        // GET: User_Department/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDepartment user_Department = db.UserDepartments.Find(id);
            if (user_Department == null)
            {
                return HttpNotFound();
            }
            return View(user_Department);

          
        }

        // GET: User_Department/Create
        public ActionResult Create()
        {
            ViewBag.DepartmentID = new SelectList(db.Departments, "DepartmentGuid", "Name");
            ViewBag.UserID = new SelectList(db.Users, "Id", "BlazerId");
            return View();
        }

        // POST: User_Department/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,UserId,DepartmentGuid")] UserDepartment user_Department)
        {
            if (ModelState.IsValid)
            {
                db.UserDepartments.Add(user_Department);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DepartmentID = new SelectList(db.Departments, "DepartmentGuid", "Name", user_Department.DepartmentGuid);
            ViewBag.UserID = new SelectList(db.Users, "Id", "BlazerId", user_Department.UserId);
            return View(user_Department);
        }

        // GET: User_Department/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDepartment user_Department = db.UserDepartments.Find(id);
            if (user_Department == null)
            {
                return HttpNotFound();
            }
            ViewBag.DepartmentID = new SelectList(db.Departments, "DepartmentGuid", "Name", user_Department.DepartmentGuid);
            ViewBag.UserID = new SelectList(db.Users, "Id", "BlazerId", user_Department.UserId);
            return View(user_Department);
        }

        // POST: User_Department/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,UserId,DepartmentGuid")] UserDepartment user_Department)
        {
            if (ModelState.IsValid)
            {
                db.Entry(user_Department).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DepartmentID = new SelectList(db.Departments, "DepartmentGuid", "Name", user_Department.DepartmentGuid);
            ViewBag.UserID = new SelectList(db.Users, "Id", "BlazerId", user_Department.UserId);
            return View(user_Department);
        }

        // GET: User_Department/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDepartment user_Department = db.UserDepartments.Find(id);
            if (user_Department == null)
            {
                return HttpNotFound();
            }
            return View(user_Department);
        }

        // POST: User_Department/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            UserDepartment user_Department = db.UserDepartments.Find(id);
            db.UserDepartments.Remove(user_Department);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
