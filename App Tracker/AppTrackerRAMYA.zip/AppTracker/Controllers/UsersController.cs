﻿using AppTracker.Models;
using AppTracker.Services.Services;
using AppTracker.ViewModels;
using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Mvc;

namespace AppTracker.Controllers
{
    public class UsersController : Controller
    {
        private db_UAB_AppTrackerEntities db = new db_UAB_AppTrackerEntities();
        public UserService _userService = new UserService();
        public DepartmentService _departmentService = new DepartmentService();
        public RoleService _roleService = new RoleService();
        public UserDepartmentService _userDepartmentService = new UserDepartmentService();

        // GET: Users
        public ActionResult Index()
        {
            return View(_userService.GetUsers());
        }

        // GET: Users/Details/5
        public ActionResult Details(int? Id)
        {
            if (Id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            return View(_userService.GetUserById(Id));
        }

        //Return NewUserForm
        public ActionResult New()
        {
            var viewModel = new UserFormsVM
            {
                Roles = _roleService.GetRoles(),
                DepartmentsDropDown = new MultiSelectList(_departmentService.GetDepartments(), "DepartmentGuid", "Name"),
            };
            return View("NewUserForm", viewModel);
        }

        //Return EditUserForm
        public ActionResult Edit(int? Id)
        {
            if (Id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var user = _userService.GetUserById(Id);

            if (user == null)
            {
                return HttpNotFound();
            }

            //Selects all the departments the user already has (These are the ones that need to be checked)
            var userDepartments = _userDepartmentService.GetUserDepartmentsByUserId(Id);

            var seletedDepartmentGuids = new List<Guid>();

            foreach (var department in userDepartments)
            {
                seletedDepartmentGuids.Add(department.DepartmentGuid);
            }

            //UserFormVM Ctor
            var viewModel = new UserFormsVM(user)
            {
                Roles = _roleService.GetRoles(),
                DepartmentsDropDown = new MultiSelectList(_departmentService.GetDepartments(), "DepartmentGuid", "Name", seletedDepartmentGuids)
            };

            return View("EditUserForm", viewModel);
        }

        //POST: Add or Update user to the Database depending if the User exists or Not
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(UserFormsVM user)
        {
            if (!ModelState.IsValid)
            {
                var viewModel = new UserFormsVM
                {
                    Roles = _roleService.GetRoles(),
                    DepartmentsDropDown = new MultiSelectList(_departmentService.GetDepartments(), "DepartmentGuid", "Name")
                };

                if (user.Id == 0)
                {
                    return View("NewUserForm", viewModel);
                }
                else
                {
                    return View("EditUserForm", viewModel);
                }
            }

            //Add User and UserDepartments
            if (user.Id == 0)
            {
                _userService.AddUser(user);
                _userDepartmentService.AddUserDepartments(user.BlazerId, user.selectedDepartmentGuids);
            }

            //Update User and UserDepartments
            else if (user.selectedDepartmentGuids == null)
            {
                _userService.UpdateUser(user);
                _userDepartmentService.DeleteUserDepartmentsByUserId(user.Id);
            }
            else
            {
                _userService.UpdateUser(user);
                _userDepartmentService.DeleteUserDepartmentsByUserId(user.Id);
                _userDepartmentService.AddUserDepartments(user.BlazerId, user.selectedDepartmentGuids);
            }
            return RedirectToAction("Index", "Users");
        }

        // GET: Users/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }


        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            User user = db.Users.Find(id);
            db.Users.Remove(user);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
