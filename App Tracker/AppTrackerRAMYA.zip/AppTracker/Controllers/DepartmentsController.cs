﻿using AppTracker.Models;
using System;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace AppTracker.Controllers
{
    public class DepartmentsController : Controller
    {
        private db_UAB_AppTrackerEntities db = new db_UAB_AppTrackerEntities();

        // GET: Departments
        public ActionResult Index()
        {
            return View(db.Departments.ToList());
        }

        // GET: Departments/Details/5
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Department Departments = db.Departments.Find(id);
            if (Departments == null)
            {
                return HttpNotFound();
            }
            return View(Departments);
        }

        // GET: Departments/Create
        public PartialViewResult CreateView()
        {
            return PartialView("~/Shared/_AddDepartmentsModal");
        }

        // POST: Departments/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "DepartmentGuid,Name")] Department Department)
        {
            if (ModelState.IsValid)
            {
                db.Departments.Add(Department);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(Department);
        }

        // GET: Departments/Edit/5
        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Department Department = db.Departments.Find(id);
            if (Department == null)
            {
                return HttpNotFound();
            }
            return View(Department);
        }

        // POST: Departments/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DepartmentsGUID,Name")] Department Departments)
        {
            if (ModelState.IsValid)
            {
                db.Entry(Departments).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(Departments);
        }

        // GET: Departments/Delete/5
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Department Departments = db.Departments.Find(id);
            if (Departments == null)
            {
                return HttpNotFound();
            }
            return View(Departments);
        }

        // POST: Departments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
            Department Departments = db.Departments.Find(id);
            db.Departments.Remove(Departments);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
