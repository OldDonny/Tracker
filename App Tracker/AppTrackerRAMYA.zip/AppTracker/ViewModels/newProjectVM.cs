﻿using System;
using AppTracker.Models;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;


namespace AppTracker.ViewModels
{
    public class newProjectVM
    {
        public int Id { get; set; }
        public Guid DepartmentGuid { get; set; }

        public string TypeId { get; set; }
        public string ProjectName { get; set; }
        public string Description { get; set; }
        public string Production { get; set; }
        public string Development { get; set; }
        public System.DateTime Created { get; set; }
        public System.DateTime? Modified { get; set; }

        public string DepartmentName { get; set; }

        public List<Department> Departments { get; set; }
        public string typeName { get; set; }
    }
}