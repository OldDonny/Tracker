﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AppTracker.Models;
using System.Web.Mvc;
using AppTracker.Services.Models;

namespace AppTracker.ViewModels
{
    public class EditLinkViewModel
    {

      
            public int ID { get; set; }
            public Guid DepartmentGuid { get; set; }

            public int TypeId { get; set; }
            public string ProjectName { get; set; }
            public string Description { get; set; }
            public string Production { get; set; }
            public string Development { get; set; }
            public System.DateTime Created { get; set; }
            public System.DateTime? Modified { get; set; }

           
            public IEnumerable<SelectListItem> Types { get; set; }


            public List<Guid> SelectedDepartmentGuids { get; set; }

            public IEnumerable<SelectListItem> Departments { get; set; }


            public string typeName { get; set; }

           public EditLinkViewModel()
            {
                ID = 0;
            }

        public EditLinkViewModel(LinksModel link)
        {
            ID = link.Id;
            DepartmentGuid = link.DepartmentGuid;
            TypeId = link.TypeId;
            ProjectName = link.ProjectName;
            Description = link.Description;
            Production = link.Production;
            Development = link.Development;
            Created = link.Created;
            Modified = null;
            //DepartmentName = link.DepartmentName;
            //Types = link.Type;
            //Departments = link.Department;
        }


    }
}