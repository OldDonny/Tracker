﻿using AppTracker.Services.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace AppTracker.ViewModels
{
    public class UserFormsVM
    {
        //User Class Fields for NewUserForm
        public int? Id { get; set; }

        [Required(ErrorMessage = "BlazerID is a required field")]
        public string BlazerId { get; set; }

        [Required(ErrorMessage = "You must choose a Role")]
        public int RoleId { get; set; }

        public string EndReason { get; set; }

        public DateTime? EndDate { get; set; }

        //Comments field for EditUserForm
        public string Comments { get; set; }

        //Roles
        public IEnumerable<RoleModel> Roles { get; set; }


        //Departments
        [Display(Name = "Departments")]
        public MultiSelectList DepartmentsDropDown { get; set; }

        public List<Guid> selectedDepartmentGuids { get; set; }

        //Ctor that Fills NewUserForm
        public UserFormsVM()
        {
            Id = 0;
        }

        //Ctor that Fills EditUserForm
        public UserFormsVM(UserModel user)
        {
            BlazerId = user.BlazerId;
            RoleId = user.RoleId;
            Comments = user.Comments;
        }


    }
}