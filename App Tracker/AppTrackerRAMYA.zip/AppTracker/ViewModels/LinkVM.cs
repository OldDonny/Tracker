﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AppTracker.Models;
using Type = AppTracker.Models.Type;

namespace AppTracker.ViewModels
{
    public class  LinkVM
    {
        public int ID { get; set; }
        public Guid DepartmentGuid { get; set; }

        public int TypeId { get; set; }
        public string ProjectName { get; set; }
        public string Description { get; set; }
        public string Production { get; set; }
        public string Development { get; set; }
        public System.DateTime Created { get; set; }
        public System.DateTime? Modified { get; set; }

        public string DepartmentName { get; set; }

        [Display(Name = "Type of project")]
        public int SelectedType { get; set; }
        public IEnumerable<SelectListItem> Types { get; set; }

        [Display(Name = "Department")]
        
        public IEnumerable<SelectListItem> Departments { get; set; }
        public string typeName { get; set; }
    }
}
