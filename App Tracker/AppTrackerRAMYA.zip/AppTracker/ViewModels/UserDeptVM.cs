﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AppTracker.Models;

namespace AppTracker.ViewModels
{
    public class UserDeptVM
    {
       

        public Guid DepartmentGuid { get; set; }
        public string  DepartmentName { get; set; }
    
    }
}