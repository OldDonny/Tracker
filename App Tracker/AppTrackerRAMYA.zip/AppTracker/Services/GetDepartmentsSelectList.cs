﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.DynamicData;
using System.Web.Mvc;
using AppTracker.Models;

namespace AppTracker.Services
{
    public class GetDepartmentsSelectList
    {


        db_UAB_AppTrackerEntities db = new db_UAB_AppTrackerEntities();


        public IEnumerable<SelectListItem> GetDepartmentsList()
        {
            var departments = db.Departments.Select(d => new {d.DepartmentGuid, d.Name}).ToList();

            // Create an empty list to hold result of the operation
            var selectList = new List<SelectListItem>();

            foreach (var department in departments)
            {
                selectList.Add(new SelectListItem
                {
                    Value = department.DepartmentGuid.ToString(),
                    Text = department.Name
                });
            }

            return selectList;


        }


    }
}