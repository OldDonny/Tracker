﻿using System.Collections.Generic;
using System.Linq;
using System.Web;
using AppTracker.Models;
using Type = System.Type;

namespace AppTracker.Services.Models
{
    public class LinksModel
    {
       
            public int Id { get; set; } // ID (Primary key)
            public string ProjectName { get; set; } // ProjectName (length: 50)
            public int TypeId { get; set; } // TypeID
            public string Description { get; set; } // Description (length: 100)
            public string Production { get; set; } // Production (length: 100)
            public string Development { get; set; } // Development (length: 100)
            public System.DateTime Created { get; set; } // Created
            public System.DateTime? Modified { get; set; } // Modified
            public System.Guid DepartmentGuid { get; set; } // DepartmentGUID

            // Foreign keys

            /// <summary>
            /// Parent Department pointed by [Links].([DepartmentGuid]) (FK_Links_Department1)
            /// </summary>
            public virtual Department Department { get; set; } // FK_Links_Department1

            /// <summary>
            /// Parent Type pointed by [Links].([TypeId]) (FK_Links_Type)
            /// </summary>
            public virtual AppTracker.Models.Type Type { get; set; } // FK_Links_Type

            public LinksModel()
            {
                DepartmentGuid = System.Guid.NewGuid();
            }
        
    }
}