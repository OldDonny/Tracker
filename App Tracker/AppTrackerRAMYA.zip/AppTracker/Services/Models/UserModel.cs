﻿using AppTracker.Models;

namespace AppTracker.Services.Models
{
    public class UserModel
    {
        public int Id { get; set; } // ID (Primary key)
        public string BlazerId { get; set; } // BlazerID (length: 50)
        public System.DateTime AccessDate { get; set; } // AccessDate
        public System.DateTime? EndDate { get; set; } // EndDate
        public string EndReason { get; set; } // EndReason
        public string Comments { get; set; } // Comments (length: 100)
        public int RoleId { get; set; } // RoleID

        

        // Reverse navigation

        /// <summary>
        /// Child UserDepartments where [User_Department].[UserID] point to this entity (FK_User_Department_Users)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<UserDepartment> UserDepartments { get; set; } // User_Department.FK_User_Department_Users

        // Foreign keys

        /// <summary>
        /// Parent Role pointed by [Users].([RoleId]) (FK_Users_Roles)
        /// </summary>
        public virtual Role Role { get; set; } // FK_Users_Roles

        public UserModel()
        {
            UserDepartments = new System.Collections.Generic.List<UserDepartment>();
        }

    }
}