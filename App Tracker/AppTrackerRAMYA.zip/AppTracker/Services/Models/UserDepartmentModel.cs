﻿using AppTracker.Models;

namespace AppTracker.Services.Models
{
    public class UserDepartmentModel
    {
        public int Id { get; set; } // ID (Primary key)
        public int? UserId { get; set; } // UserID
        public System.Guid DepartmentGuid { get; set; } // DepartmentGUID

        // Foreign keys

        /// <summary>
        /// Parent Department pointed by [User_Department].([DepartmentGuid]) (FK_User_Department_Department1)
        /// </summary>
        public virtual Department Department { get; set; } // FK_User_Department_Department1

        /// <summary>
        /// Parent User pointed by [User_Department].([UserId]) (FK_User_Department_Users)
        /// </summary>
        public virtual User User { get; set; } // FK_User_Department_Users
    }
}