﻿using AppTracker.Models;

namespace AppTracker.Services.Models
{
    public class RoleModel
    {
        public int RoleId { get; set; } // RoleID (Primary key)
        public string RoleName { get; set; } // RoleName (length: 50)

        // Reverse navigation

        /// <summary>
        /// Child Users where [Users].[RoleID] point to this entity (FK_Users_Roles)
        /// </summary>
        public virtual System.Collections.Generic.ICollection<User> Users { get; set; } // Users.FK_Users_Roles

        public RoleModel()
        {
            Users = new System.Collections.Generic.List<User>();
        }
    }
}