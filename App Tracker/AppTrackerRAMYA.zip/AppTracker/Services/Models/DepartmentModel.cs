﻿namespace AppTracker.Services.Models
{
    public class DepartmentModel
    {
        public System.Guid DepartmentGuid { get; set; } // DepartmentGUID (Primary key)
        public string Name { get; set; } // Name

    }
}