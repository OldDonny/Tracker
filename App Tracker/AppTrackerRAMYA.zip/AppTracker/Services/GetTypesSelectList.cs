﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AppTracker.Models;
using AppTracker.ViewModels;

namespace AppTracker.Services
{
    public class GetTypesSelectList
    {
        private db_UAB_AppTrackerEntities db = new db_UAB_AppTrackerEntities();


        public IEnumerable<SelectListItem> GetTypesList()
        {
            

            var types = (from t in db.Types where t.TypeId > 0 select t);

            // Create an empty list to hold result of the operation
            var selectList = new List<SelectListItem>();

            
            foreach (var type in types)
            {
                selectList.Add(new SelectListItem
                {
                    Value = type.TypeId.ToString(),
                    Text = type.TypeName
                });
            }

            return selectList;
        }
    }
}