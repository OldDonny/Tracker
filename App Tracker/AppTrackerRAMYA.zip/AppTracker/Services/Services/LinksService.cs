﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Web.Mvc;
using AppTracker.Models;
using AppTracker.Services.Models;
using AppTracker.ViewModels;

namespace AppTracker.Services.Services
{
    public class LinksService
    {
        private db_UAB_AppTrackerEntities _db = new db_UAB_AppTrackerEntities();

        //Get All Users
        public List<Link> GetLinks()
        {
            try
            {
                return
                    _db.Links.ToList(); //how can I make the List<User> a List<UserModel> list because I dont want to use the model
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        //Get Link by Id
        public LinksModel GetLinkByID(int? Id)
        {
            try
            {
                var LinksInDB = _db.Links.Find(Id);

                return new LinksModel()
                {
                    Id = LinksInDB.Id,
                    ProjectName = LinksInDB.ProjectName,
                    TypeId = LinksInDB.TypeId,
                    Description = LinksInDB.Description,
                    Production = LinksInDB.Production,
                    Development = LinksInDB.Development,
                    Created = LinksInDB.Created,
                    Modified = LinksInDB.Modified,
                    DepartmentGuid = LinksInDB.DepartmentGuid,
                    Department = LinksInDB.Department,
                    Type = LinksInDB.Type

                    //UserDepartments = //Get a list of User_Departments by user.Id
                };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public LinksModel getLinksByApp(Guid DepartmentGuid)
        {
            try
            {






                var query = (from l in _db.Links
                    join d in _db.Departments on l.DepartmentGuid equals d.DepartmentGuid
                    join t in _db.Types on l.TypeId equals t.TypeId
                    where l.TypeId == 1
                    where l.DepartmentGuid == DepartmentGuid
                    select l);


                
                    query.Select(x => new LinkVM
                    {

                        //changed typeid to in HEADS UP
                        DepartmentGuid = x.DepartmentGuid,
                        TypeId = x.TypeId,
                        Description = x.Description,
                        Production = x.Production,
                        Development = x.Development,
                        Created = x.Created,

                        Modified = x.Modified,
                        ProjectName = x.ProjectName,
                        DepartmentName = x.Department.Name,
                        typeName = x.Type.TypeName

                    }).ToList();

                return PartialView("~/Views/Shared/_ViewLinkPartial.cshtml",)
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
                throw;

            }
        }
    }


}

        //changed typeid to in HEADS UP
