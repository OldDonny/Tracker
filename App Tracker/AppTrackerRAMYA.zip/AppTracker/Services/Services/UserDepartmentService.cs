﻿using AppTracker.Models;
using AppTracker.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AppTracker.Services.Services
{
    public class UserDepartmentService
    {
        private db_UAB_AppTrackerEntities _db = new db_UAB_AppTrackerEntities();
        public UserService _userService = new UserService();

        //Get UserdDepartmets for User
        public List<UserDepartmentModel> GetUserDepartmentsByUserId(int? Id)
        {
            try
            {
                return _db.UserDepartments.Where(x => x.UserId == Id).Select(x => new UserDepartmentModel
                {
                    Id = x.Id,
                    DepartmentGuid = x.DepartmentGuid,
                    Department = x.Department,
                    User = x.User,
                    UserId = x.UserId

                }).ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }

        //Add a User_Department foreach Department the just added User selected
        public void AddUserDepartments(string blazerId, List<Guid> selectedDepartmentGuids)
        {
            try
            {

                var justAddedUser = _userService.GetUserByBlazerId(blazerId);

                foreach (var departmentGuid in selectedDepartmentGuids)
                {
                    var userDepartment = new UserDepartment()
                    {
                        UserId = justAddedUser.Id,
                        DepartmentGuid = departmentGuid
                    };

                    _db.UserDepartments.Add(userDepartment);
                    _db.SaveChanges();
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }

        public void DeleteUserDepartmentsByUserId(int? Id)
        {
            try
            {
                var userDepartments = _db.UserDepartments.Where(x => x.UserId == Id).ToList();

                foreach (var userDepartment in userDepartments)
                {
                    _db.UserDepartments.Remove(userDepartment);
                    _db.SaveChanges();
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }
    }
}
