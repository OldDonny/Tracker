﻿using AppTracker.Models;
using AppTracker.Services.Models;
using AppTracker.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AppTracker.Services.Services
{
    public class UserService
    {
        private db_UAB_AppTrackerEntities _db = new db_UAB_AppTrackerEntities();

        //Get All Users
        public List<User> GetUsers()
        {
            try
            {
                return _db.Users.ToList(); //how can I make the List<User> a List<UserModel> list because I dont want to use the model
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        //Get User by Id
        public UserModel GetUserById(int? Id)
        {
            try
            {
                User userInDb = _db.Users.Find(Id);

                return new UserModel
                {
                    Id = userInDb.Id,
                    BlazerId = userInDb.BlazerId,
                    AccessDate = userInDb.AccessDate,
                    Comments = userInDb.Comments,
                    EndDate = userInDb.EndDate,
                    EndReason = userInDb.EndReason,
                    RoleId = userInDb.RoleId,
                    Role = userInDb.Role
                    //UserDepartments = //Get a list of User_Departments by user.Id
                };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        //Get User by BlazerId
        public UserModel GetUserByBlazerId(string blazerId)
        {
            try
            {
                User userInDb = _db.Users.Single(x => x.BlazerId == blazerId);

                return new UserModel
                {
                    Id = userInDb.Id,
                    BlazerId = userInDb.BlazerId,
                    AccessDate = userInDb.AccessDate,
                    Comments = userInDb.Comments,
                    EndDate = userInDb.EndDate,
                    EndReason = userInDb.EndReason,
                    RoleId = userInDb.RoleId,
                    Role = userInDb.Role,
                    //UserDepartments = userInDb.UserDepartments
                };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }


        //Add User
        public void AddUser(UserFormsVM user)
        {
            try
            {
                var newUser = new User()
                {
                    AccessDate = DateTime.Now,
                    BlazerId = user.BlazerId,
                    RoleId = user.RoleId,
                };

                _db.Users.Add(newUser);
                _db.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        //Update User
        public void UpdateUser(UserFormsVM user)
        {
            try
            {
                User userInDb = _db.Users.Single(m => m.Id == user.Id);

                userInDb.AccessDate = userInDb.AccessDate; //AccesDate has to stay the same
                userInDb.BlazerId = user.BlazerId;
                userInDb.RoleId = user.RoleId;
                userInDb.Comments = user.Comments;
                userInDb.EndDate = user.EndDate;
                userInDb.EndReason = user.EndReason;

                _db.SaveChanges();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        //Delete User




    }
}