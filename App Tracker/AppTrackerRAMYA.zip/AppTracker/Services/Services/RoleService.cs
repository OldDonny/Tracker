﻿using AppTracker.Models;
using AppTracker.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AppTracker.Services.Services
{
    public class RoleService
    {
        private db_UAB_AppTrackerEntities _db = new db_UAB_AppTrackerEntities();

        //Get All Roles
        public List<RoleModel> GetRoles()
        {
            try
            {
                return _db.Roles.Select(x => new RoleModel
                {
                    RoleId = x.RoleId,
                    RoleName = x.RoleName
                })
                    .ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }
    }
}