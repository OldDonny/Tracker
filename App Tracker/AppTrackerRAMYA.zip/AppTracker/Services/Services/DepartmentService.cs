﻿using AppTracker.Models;
using AppTracker.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AppTracker.Services.Services
{
    public class DepartmentService
    {
        private db_UAB_AppTrackerEntities _db = new db_UAB_AppTrackerEntities();

        //Get All Departments
        public List<DepartmentModel> GetDepartments()
        {
            try
            {
                return _db.Departments.Select(x => new DepartmentModel
                {
                    DepartmentGuid = x.DepartmentGuid,
                    Name = x.Name
                })
                    .ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }

    }
}