﻿


using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.EnterpriseServices;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Web;
using System.Web.DynamicData;
using System.Web.Mvc;
using AppTracker.Models;
using AppTracker.ViewModels;
using AppTracker.Services;

namespace AppTracker.Services
{


    public class SelectedDepartmentService
    {
        private db_UAB_AppTrackerEntities db = new db_UAB_AppTrackerEntities();

        public IEnumerable<SelectList> getRemainingDepartments(Guid DepartmentGuid)
        {
            var userDepartments = (from ud in db.UserDepartments join u in db.Users on ud.Id equals u.Id select ud);

            var seletedDepartmentGuids = new List<>();


            foreach (var department in userDepartments)
            {


                seletedDepartmentGuids.Add(department);
            }

        }

    }

}




