﻿$(document).ready(function() {
    $("#userAlert").show();
})