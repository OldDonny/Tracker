﻿
//Datatables initialize

$(document).ready(function () {
   

    
    $('#mytable1').DataTable(
        {
            
            scrollY: 400,
            
            paging: true,
            sorting: true,
            pageResize: true

        }
        );


        $('#mytable3').DataTable(
            {
                scrollY: 800,
               
                paging: true,
                sorting: true,
                pageResize: true

    }
    );

    $('#mytable2').DataTable(
      {

          scrollY: 400,
          scrollCollapse: true,
          paging: true,
          sorting: true,
          pageResize: true

      }
      );
    // Apply a search to the second table for the demo
  
});

$(function () {
    $('[data-toggle="tooltip"]').tooltip()
})


//Multiple Select Plugin Initialize

$(function() {
    $('#departments').multiselect({
        includeSelectAllOption: true
});
});